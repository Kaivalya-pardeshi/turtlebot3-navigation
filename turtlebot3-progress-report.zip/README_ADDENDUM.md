Add this to the main README under Documentation:

```markdown
- [Development progress and debugging evidence](docs/PROGRESS_LOG.md)
```
