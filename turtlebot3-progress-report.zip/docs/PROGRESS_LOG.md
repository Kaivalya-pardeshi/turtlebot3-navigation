# Engineering Progress & Debugging Log

**Project:** TurtleBot3 Autonomous Navigation — ROS 2 Humble, Nav2, Gazebo Classic  
**Environment:** Windows 11, WSL 2, Ubuntu 22.04.5, ROS 2 Humble, Gazebo Classic 11.10.2, AMD Radeon integrated graphics  
**Evidence dates:** 27 October 2026 (screenshots supplied during hands-on setup)  
**Status:** Simulation, robot sensors, map visualization, AMCL and BT Navigator activation demonstrated; **successful autonomous goal completion not yet verified**.

## Purpose

This document is an evidence-based account of the setup, experiments, failures, and debugging performed while integrating stock TurtleBot3 and Nav2 packages. It records real observed terminal output and the corrective steps used. It is not a claim that every assignment deliverable has already passed. Screenshots are linked under `docs/screenshots/`.

## Progress at a glance

| Component | Evidence | Result |
|---|---|---|
| Ubuntu 22.04 / WSL 2 | OS version and terminal screenshots | Verified |
| ROS 2 Humble | `ros2 --help`, `$ROS_DISTRO=humble` | Verified |
| ROS 2 pub/sub | Talker and listener receiving messages | Verified |
| Gazebo Classic + TurtleBot3 | Gazebo 11.10.2, simulation GUI, model sensor topics | Verified |
| Laser and odometry | `/scan` LaserScan sample, `/odom` sample | Verified |
| Nav2 packages and map | TurtleBot3 YAML map and RViz occupancy display | Verified |
| AMCL + BT Navigator | `ros2 lifecycle get` returned `active [3]` for both | Verified at time of screenshot |
| Robot-to-map transform | `tf2_echo map base_link` returned translation and rotation | Verified at time of screenshot; **pose alignment not independently validated** |
| Goal accepted and reached | No definitive `NavigateToPose` success result captured | **Pending** |
| Obstacle avoidance outcome | No complete measured obstacle-avoidance run captured | **Pending** |
| Custom Python diagnostics | Source included in the repository archive | **Runtime/build verification pending** |

## Chronological record

### 1. WSL installation blocked by HTTP 403

**Observed:** `wsl --install -d Ubuntu-22.04` and later `--web-download` returned `Forbidden (403)`.  
**Investigation and action:** Attempted Microsoft Store installation, checked download queue, reset Store cache; Store download then began.  
**Outcome:** Continued to Ubuntu provisioning. The screenshot captures the initial error, not the full network root cause.

![WSL installation request returned Forbidden 403](screenshots/01-wsl-403.png)

### 2. WSL required feature not enabled

**Observed:** `WslRegisterDistribution failed with error: 0x80370114`, followed by “a required feature is not installed.”  
**Action:** Enabled Windows Subsystem for Linux and Virtual Machine Platform features with DISM and restarted Windows.  
**Outcome:** Ubuntu provisioning subsequently proceeded successfully. This is strong circumstantial evidence of the fix; no separate Windows feature-state export was saved.

![WSL required-feature error](screenshots/02-wsl-missing-feature.png)

### 3. Incorrect Ubuntu distribution installed

**Observed:** The generic Ubuntu Store app opened Ubuntu **26.04.1 LTS**. ROS 2 Humble binary packages were intended for Ubuntu **22.04**.  
**Action:** Installed the explicitly named `Ubuntu-22.04` WSL distribution alongside the existing one; verified `jammy` release.  
**Outcome:** Ubuntu 22.04.5 LTS working. Later, opening a terminal in the wrong distribution also caused `ros2: command not found`, resolved by selecting `wsl -d Ubuntu-22.04`.

![Wrong Ubuntu release](screenshots/03-ubuntu-26-mismatch.png)
![Correct Ubuntu 22.04 verification](screenshots/04-ubuntu-22-installed.png)

### 4. Installed and verified ROS 2 Humble

**Action:** Configured the official ROS APT source, installed `ros-humble-desktop`, sourced `/opt/ros/humble/setup.bash`, checked `ros2 --help` and `echo $ROS_DISTRO`.  
**Outcome:** ROS CLI responded and `ROS_DISTRO` was `humble`.

![ROS 2 repository candidate](screenshots/05-ros-repository.png)
![ROS 2 Humble CLI installation verification](screenshots/06-ros-installed.png)

### 5. ROS publisher/subscriber check

**Observed:** A Talker published `Hello World` on `/chatter`, and a Listener subsequently received the messages. An earlier `ros2 topic echo /chatter` failed because the Talker had already been stopped with Ctrl+C.  
**Action:** Ran Talker and Listener simultaneously in separate Ubuntu 22.04 terminals.  
**Outcome:** ROS inter-process pub/sub communication demonstrated.

![Talker/listener data received](screenshots/07-talker-listener.png)

### 6. WSL GUI and Gazebo setup

**Action:** Tested OpenGL with `glxinfo -B`. Installed Gazebo Classic and TurtleBot3 Humble simulation packages.  
**Observed:** D3D12 AMD Radeon renderer reported, `Accelerated: yes`, OpenGL 4.2, Gazebo 11.10.2.  
**Outcome:** Hardware-backed Linux GUI rendering available; real-time performance varies by run.

![GPU acceleration information](screenshots/08-gpu-acceleration.png)
![Gazebo and TurtleBot3 packages](screenshots/09-gazebo-packages.png)

### 7. Initial TurtleBot3 spawn failure

**Observed:** Gazebo started `gzserver` and `gzclient`, but the spawn script reported `/spawn_entity` unavailable after waiting and exited. The Gazebo obstacle world was rendered, while `/scan` was absent.  
**Investigation:** Checked Gazebo processes and listed ROS services. The `/spawn_entity` service became available later, indicating delayed initialization rather than proof of a permanently missing plugin.  
**Action:** Ran `gazebo_ros spawn_entity.py` with the Waffle SDF after the service became available.  
**Outcome:** `/scan` LaserScan data subsequently appeared and `/odom` was read; robot sensor simulation was working. No timestamped spawn success log was retained.

![Spawn timeout](screenshots/10-spawn-timeout.png)
![Obstacle world running](screenshots/11-gazebo-world.png)
![Laser topic missing before spawn](screenshots/12-scan-missing.png)
![Spawn service available later](screenshots/13-spawn-service-available.png)

### 8. RViz launch, localization and TF errors

**Observed:** RViz showed the occupancy map, but initially logged `Invalid frame ID "map"`, timeouts waiting for `base_link` to `map`, and AMCL warnings requesting an initial pose. RViz also showed errors loading optional `Docking` and `Selector` panels.  
**Investigation:** Verified `/amcl` and `/bt_navigator` lifecycle states. After Nav2 was running, both returned `active [3]`. A later `tf2_echo map base_link` printed valid transforms.  
**Outcome:** TF path became available. However, TF connectivity alone does not prove correct physical/map alignment; an aligned scan and completed goal are still required. Optional panel plugin failures remained a UI issue in the captured configuration.

![RViz occupancy map and optional panel errors](screenshots/14-rviz-loaded.png)
![Missing map frame warnings](screenshots/15-map-frame-error.png)
![Lifecycle nodes active](screenshots/16-nav2-active.png)
![Valid map-to-base-link transform](screenshots/17-map-transform.png)
![Costmaps visible in RViz](screenshots/18-rviz-costmap.png)

### 9. Gazebo GUI recovery

**Observed:** The Gazebo window temporarily could not be found from the Windows taskbar.  
**Investigation:** `pgrep -a gzserver` and `pgrep -a gzclient` showed both processes alive.  
**Outcome:** The Gazebo UI later became visible again with laser visualization. This confirmed the graphical interface, but does not on its own prove a goal was executed.

![Gazebo processes present](screenshots/19-gazebo-processes.png)
![Gazebo GUI visible](screenshots/20-gazebo-recovered.png)

## Engineering observations

1. A simulator GUI is not proof that the robot has spawned. Check `/spawn_entity`, `/scan`, `/odom`, and the model list separately.
2. On systems with several WSL distributions, verify the Ubuntu release before sourcing ROS; ROS Humble installed in one distribution is not installed in the other.
3. `map → odom → base_link` connectivity is a prerequisite for most Nav2 operations, but a valid TF response is not sufficient to demonstrate localization accuracy.
4. ROS 2 lifecycle `active` means the node is running in that lifecycle state, not that a goal has completed.
5. A navigation demonstration requires a recorded action result or a clearly observed goal arrival, not just a goal arrow or a colored costmap.

## Remaining validation checklist

- [ ] Run `colcon build --base-paths src --symlink-install` successfully in the target Ubuntu environment.
- [ ] Source `install/setup.bash`; test the custom `health_check` and `send_goal` utilities.
- [ ] Confirm robot pose using laser-to-map alignment.
- [ ] Send a safe, reachable goal; capture `NavigateToPose` **SUCCEEDED** and visible arrival in Gazebo.
- [ ] Run an obstacle-avoidance goal and record outcome, elapsed time, and any recoveries.
- [ ] Record a 1–2 minute screen capture with Gazebo and RViz side-by-side.
- [ ] Update the main README and submission answers with only validated outcomes.

## How to extend this log

For each new experiment, append: **date/time, objective, exact command/settings, expected result, observed result, relevant screenshot/log, diagnosis, next change**. Separate hypotheses from verified causes. Never edit an original screenshot to create a result that was not observed.

---

*Source note: screenshots came from the development conversation on 27 October 2026. Their filenames describe the evidence; they are not independent run logs or a substitute for final end-to-end testing.*
